
Hooks.on("ready", function() {
  console.log("Artificer (13th Age) class injecting data into the system...");

  /*
   * Add new race - this enables race recognition.
   */
  // ARCHMAGE.raceList["newrace"] = "NewRace";

  /*
   * Add new class name to classList - this enable class recognition.
   */
  CONFIG.ARCHMAGE.classList["artificer"] = "Artificer";

  /*
   * Add class stats to classes - this enables base stats autoconfiguration.
   */
  CONFIG.ARCHMAGE.classes["artificer"] = {
    hp: 6,                  // Base hp modifier
    ac_lgt: 12,             // Base AC in light/no armor (best value)
    ac_hvy: 14,             // Base AC in heavy armour
    ac_hvy_pen: -2,         // Attack penalty for wearing heavy armour
    shld_pen: -2,           // Attack penalty for using a shield
    pd: 11,                 // Base PD
    md: 11,                 // Base MD
    rec_die: 6,             // Recovery die size (number of faces), before talents/feats
    wpn_1h: 6,              // Weapon die size (# of faces), one-handed melee (best number without penalty)
    wpn_2h: 8,              // Weapon die size (# of faces), two-handed melee (best number without penalty if possible)
    wpn_2h_pen: 0,          // Attack penalty for using indicated two-handed weapon
    wpn_rngd: 6,            // Weapon die size (# of faces), ranged (best number without penalties)
    skilled_warrior: false  // Whether the class counts as a skilled warrior for multiclassing purposes
  };

  /*
   * Add class description pack - adds descriptions to class page in power importer.
   */
  CONFIG.ARCHMAGE.classPacks.push("classes-artificer");

  /* 
   * Add some picks to keyModifiers - this sets the default Key Modifier upon selecting two recognized class names.
   * Due to the way this is stored in the system the new class must be added to all other classes that come earlier in
   * alphabetical order and all classes that come after it must be added to this class entry.
   */
  CONFIG.ARCHMAGE.keyModifiers['artificer']['barbarian'] = ['str', 'int'];
  CONFIG.ARCHMAGE.keyModifiers['artificer']['bard'] = ['int', 'cha'];
  CONFIG.ARCHMAGE.keyModifiers['artificer']['chaosmage'] = ['int', 'cha'];
  CONFIG.ARCHMAGE.keyModifiers['artificer']['cleric'] = ['wis', 'int'];
  CONFIG.ARCHMAGE.keyModifiers['artificer']['commander'] = ['cha', 'int'];
  CONFIG.ARCHMAGE.keyModifiers['artificer']['druid'] = ['wis', 'int'];
  CONFIG.ARCHMAGE.keyModifiers['artificer']['fighter']['artificer'] = ['str', 'int'];
  CONFIG.ARCHMAGE.keyModifiers['artificer']['monk'] = ['dex', 'int'];
  CONFIG.ARCHMAGE.keyModifiers['artificer']['necromancer'] = ['int', 'cha'];
  CONFIG.ARCHMAGE.keyModifiers['artificer']['occultist'] = ['int', 'cha'];
  CONFIG.ARCHMAGE.keyModifiers['artificer']['paladin'] = ['str', 'int'];
  CONFIG.ARCHMAGE.keyModifiers['artificer']['ranger'] = ['dex', 'int'];
  CONFIG.ARCHMAGE.keyModifiers['artificer']['rogue'] = ['dex', 'int'];
  CONFIG.ARCHMAGE.keyModifiers['artificer']['rogue'] = ['dex', 'int'];
  CONFIG.ARCHMAGE.keyModifiers['artificer']['sorcerer'] = ['int', 'cha'];
  CONFIG.ARCHMAGE.keyModifiers['artificer'] = {
    'wizard': ['int', 'dex'],
  };

  /*
   * Add custom resources - this configures the specified resource(s) and its(their) rest behavior.
   * These are stored as an array of couples (arrays) with the resource label and rest behavior, such as:
   * - none: do not modify the resource on resting
   * - quick: refill the resource on any rest
   * - full: refill the resource on a full heal up only
   * - quickreset: reset the resource to zero on any rest
   * - fullreset: reset the resource to zero on a full heal up only
   */
  // CONFIG.ARCHMAGE.classResources['artificer'] = [["My New Resource 1", "quick"], ["My New Resource 2", "none"]];

  console.log("Artificer (13th Age) class loaded succesfully." );
});

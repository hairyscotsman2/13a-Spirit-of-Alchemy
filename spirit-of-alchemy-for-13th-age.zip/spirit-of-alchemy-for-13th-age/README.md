# Spirit of Alchemy (13th Age) Classes for the Toolkit13 System

This Foundry VTT module adds the Artificer, Emotive and Shaman classes for 13th Age to the Toolkit13 system. 

## Installation
After downloading
For local installation
copy and paste the folder (or extracted folder) into modules, restart and enable it in the manage modules menu. Restart world.

For Forge: Go to
My foundry
Summon Import Wizard (Under Table Tools)
Select the folder
Import
Enable the module in the manage modules menu of your world. Restart world
## Compatibility

Compatible with Foundry VTT v12 and later.
Requires Toolkit13 (13th Age compatible) system version 1.30.4 or later.
Tested with Foundry VTT v11.315 and Toolkit13 version 1.30.4.


